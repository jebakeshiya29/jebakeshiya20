document.getElementsByTagName("h1")[0].style.fontSize = "6vw";function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);
  if (section) {
    section.scrollInto